============================================================
  EDUCAMP 2026 - STANDALONE TRANSPARENT TIMER & CHAT OVERLAY
============================================================

Aplikasi overlay desktop transparan untuk Windows yang tersinkronisasi 
langsung secara realtime dengan Web Timer & Live Chat Educamp 2026.

FITUR UTAMA:
1. Tampilan Horizontal Ultra-Compact (Timer mepet kiri, Live Chat kanan).
2. Mode Transparan / Borderless (Bisa digeser pakai mouse drag).
3. Kompatibel dengan OBS Studio (Window Capture & Green Screen Chroma Key).
4. Mode View: Keduanya (Timer + Chat), Hanya Timer, atau Hanya Chat.
5. Klik kanan pada overlay untuk membuka menu Pengaturan (Font, Warna, Skala, dll).

CARA MENJALANKAN (PILIH SALAH SATU):

--- CARA 1 (PALING MUDAH & CEPAT) ---
1. Pastikan laptop/PC Windows Anda sudah terinstal Python (dari python.org).
2. Klik ganda file:
   start_timer_overlay.bat
3. Overlay akan langsung muncul di layar.

--- CARA 2 (JIKA INGIN MEMBUAT FILE .EXE STANDALONE) ---
1. Buka Command Prompt di folder ini.
2. Jalankan:
   Cara_Buat_EXE_di_Windows.bat
   atau jalankan perintah:
   pip install pillow pystray pyinstaller
   pyinstaller --noconfirm --onedir --windowed --name TimerOverlay timer_overlay.py
3. File TimerOverlay.exe akan terbentuk di folder dist/TimerOverlay/!
