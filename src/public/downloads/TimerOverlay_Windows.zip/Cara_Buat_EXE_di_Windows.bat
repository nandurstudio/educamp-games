@echo off
title Buat TimerOverlay.exe Sendiri (Windows)
echo ====================================================
echo   BUILD STANDALONE WINDOWS EXE - TIMER OVERLAY
echo ====================================================
echo.
echo 1. Menginstall dependensi (pillow, pystray, pyinstaller)...
pip install pillow pystray pyinstaller
echo.
echo 2. Memulai proses compile ke TimerOverlay.exe...
pyinstaller --noconfirm --onedir --windowed --name "TimerOverlay" timer_overlay.py
echo.
echo ====================================================
echo SELESAI!
echo File executable tersimpan di: dist\TimerOverlay\TimerOverlay.exe
echo ====================================================
pause
